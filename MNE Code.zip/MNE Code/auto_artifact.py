import sys
import mne
import pandas as pd
import numpy as np

def _auto_artifact(raw, x, change_points):
    '''x is the transposed DataFrame returned by raw.get_data(), change_points is a pd.Series with onsets and offsets'''
    # there are 4 separate arrays, one for each channel
    shock_durations = [[], [], [], []]
    # onsets will get overwritten each time, so only the last channel will matter
    # this is lazy programming, but they should all have the same onsets so meh
    shock_onsets = []
    for ch_num, chan in enumerate(raw.info['ch_names']):
        moving_avg = x[chan].rolling(25, center=True).mean()

        shock_cntr = 0
        shock_onsets = []
        for i in range(1, len(change_points)):
            if change_points[change_points.index[i]] == False:
                # need to count back 3 frames because that's when it first became flat
                onset = change_points.index[i - 1] - 3
                offset = change_points.index[i]

                # pt 112 has a strange shock pattern where she voltage flattens out again right after
                # the shock. That part should be counted as part of the shock
                for j in range(i, len(change_points)):
                    # this will consolidate a new shock that begins within 200 ms of the offset
                    if change_points.index[j] - offset < int(raw.info['sfreq'] / 5):
                        offset = change_points.index[j]

                duration = offset - onset

                # assume that only shocks are at least 1 second long, anything less is
                # probably just a random flat segement
                if duration > raw.info['sfreq']:
                    shock_cntr += 1
                    shock_onsets.append(onset)
                    # take the derivative of the moving average, and then take the moving average 
                    # of the derivative to smooth it out. Start a few frames after the shock offset
                    dy = moving_avg.diff().rolling(10, center=True).mean()[offset + 5:]
                    post_shock_sign = np.sign(moving_avg[offset + 5: int(offset + 5 + raw.info['sfreq'] / 4)].median())
                    # so if the post_shock is negative, we need to wait for a pos_to_neg (-2.0) change
                    # and if the post_shock is positive, we need to wait for a neg-to-pos (+2.0) change
                    zeros = dy[np.sign(dy).diff() == +2.0 * post_shock_sign]
                    found_aftershock = False
                    t = zeros.index[0]
                    # if a zero is found within 3 seconds of shock onset
                    if t < offset + raw.info['sfreq'] * 3:
                        shock_durations[ch_num].append(t - onset)
                        found_aftershock = True
                    if not found_aftershock:
                        shock_durations[ch_num].append(duration)

    # use the longest duration of the 4 channels
    consensus_durations = []
    for i in range(len(shock_onsets)):
        sorted_durations = sorted([shock_durations[ch][i] for ch in range(4)])
        consensus_durations.append(sorted_durations[3])

    onsets = np.array(shock_onsets) / float(raw.info['sfreq'])
    durations = np.array(consensus_durations) / float(raw.info['sfreq'])
    ann = mne.Annotations(onsets, durations, ['BAD_' for s in consensus_durations])
    raw.set_annotations(ann)

    return raw


def auto_artifact_from_scratch(pt_num):
    raw = mne.io.read_raw_fif(f'data/{pt_num}/stimulated_ieeg.fif')
    x = pd.DataFrame(raw.get_data().transpose(), columns=raw.info['ch_names'])

    # we define an artifact as anything that has been flat for 3 frames
    ch_flat = []
    for chan in raw.info['ch_names']:
        ch_flat.append((x[chan].diff() == 0) & (x[chan] == x[chan].shift().shift()) & (x[chan] == x[chan].shift().shift().shift()))
    x['is_artifact'] = ch_flat[0] & ch_flat[1] & ch_flat[2] & ch_flat[3]

    # change points are candidates for shock onset and offset
    change_points = x[x['is_artifact'].diff() == True]['is_artifact']

    # btw, I previously defined artifacts as areas that max out voltage, but there are some
    # post-stim artifacts that are flat but not necessarily maxed

    return _auto_artifact(raw, x, change_points)


def auto_artifact_from_annot(raw: mne.io.Raw):
    '''raw should have suspected stims annotated already, this algo will just extend those existing stims'''
    x = pd.DataFrame(raw.get_data().transpose(), columns=raw.info['ch_names'])

    # we define an artifact as anything that has been flat for 3 frames
    change_times = []
    change_vals = []
    for ann in raw.annotations:
        if ann['description'].startswith('BAD_'):
            onset = int(ann['onset'] * raw.info['sfreq'])
            offset = int((ann['onset'] + ann['duration']) * raw.info['sfreq'])
            change_times.append(onset)
            change_vals.append(True)
            change_times.append(offset)
            change_vals.append(False)

    # change points are candidates for shock onset and offset
    change_points = pd.Series(data=change_vals, index=change_times)

    return _auto_artifact(raw, x, change_points)


def add_pre_shock_labels(raw: mne.io.Raw, pre_shock_duration = 1.0):
    # the time between shocks is always <= 10.0 seconds
    max_time_bn_shocks = 10.0
    last_onset = -1000
    pre_shock_onsets = []
    for ann in raw.annotations:
        if ann['onset'] - last_onset > max_time_bn_shocks:
            pre_shock_onsets.append(ann['onset'] - pre_shock_duration)
        last_onset = ann['onset']

    for onset in pre_shock_onsets:
        raw.annotations.append(onset, pre_shock_duration, 'pre_shock')


def add_post_shock_labels(raw: mne.io.Raw, post_shock_duration = 1.0):
    post_shock_onsets = []
    for ann in raw.annotations:
        if ann['description'] == 'BAD_':
            post_shock_onsets.append(ann['onset'] + ann['duration'] + 2.0 / raw.info['sfreq'])

    for onset in post_shock_onsets:
        raw.annotations.append(onset, post_shock_duration, 'post_shock')


def label_pt(pt_num):
    raw = auto_artifact_from_scratch(pt_num)
    add_pre_shock_labels(raw, 1.0)
    add_post_shock_labels(raw, 1.0)
    raw.plot(block=True)
    raw.annotations.save(f'data/{pt_num}/auto_annotated.csv', overwrite=True)


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(f'Usage: python {sys.argv[0]} all')
        print(f'Or:    python {sys.argv[0]} <patient number>')
        sys.exit(0)
    
    if sys.argv[1] == 'all':
        pts_w_any_stim = [100, 103, 105, 110, 111, 112, 113, 115]
        for pt_num in pts_w_any_stim:
            label_pt(pt_num)
    else:
        pt_num = int(sys.argv[1])
        label_pt(pt_num)