from datetime import timedelta
import os
import sys
import pandas as pd
from read_ecog_data import read_header, read_dat_file

# config
pd.options.mode.chained_assignment = None

# constants
ONE_DRIVE = 'C:/Users/seand/Baylor College of Medicine/ '

# run once
pt_id_map = pd.read_csv('num2id.csv') # removed line "104,425079,"
exp_data = pd.read_excel(f'{ONE_DRIVE}/RNS Project Data 2021.xlsx', 'Data')

def find_files_for_day(catalog_path, date):
    catalog = pd.read_csv(catalog_path)
    intentional = catalog[catalog['ECoG trigger'] == 'Real_Time']
    intentional.loc[:,'Timestamp'] = pd.to_datetime(catalog['Timestamp'])
    same_day = intentional[(intentional['Timestamp'] > date) & (intentional['Timestamp'] < date + timedelta(days=1))]
    return same_day['Filename']
    

def save_file_for_day(date, did_stim, pt_id, pt_num):
    catalog_path = f"{ONE_DRIVE}/ECoG Data/{pt_id}/{pt_id}_ECoG_Catalog.csv"
    fnames = find_files_for_day(catalog_path, date)
    print(f'Found {len(fnames)} files on the day of the experiment')
    print(pt_num, date, did_stim)
    
    for dat_file in fnames:
        complete_path = f"{ONE_DRIVE}/EcoG Data/{pt_id}/{pt_id} Data/{dat_file}"
        raw = read_dat_file(complete_path, catalog_path)
        raw.plot(block=True)
        if input('Use this file? y/n:') == 'y':
            pt_folder = f'data/{pt_num}'
            if not os.path.exists(pt_folder):
                os.mkdir(pt_folder)
            exp_type = 'stimulated' if did_stim else 'control'
            raw.save(f'{pt_folder}/{exp_type}_ieeg.fif', overwrite=True)
            print('Saved file')
        else:
            print('Moving onto next file')


def get_pt_info(pt_num):
    cur_pt = exp_data['Participant_Number'] == pt_num
    date1 = exp_data[cur_pt]['Date_of_V1'].item()
    date2 = exp_data[cur_pt]['Date_of_V2'].item()
    did_stim1 = exp_data[cur_pt]['V1_Stim'].item()
    did_stim2 = exp_data[cur_pt]['V2_Stim'].item()
    return date1, did_stim1, date2, did_stim2


if __name__ == '__main__':
    start = -1
    if len(sys.argv) > 1: # allows us to skip patients we've already done
        start = int(sys.argv[1])
    for idx, row in pt_id_map[['Patient ID', 'ID (Memory study)']].iterrows():
        if idx < start:
            continue
        pt_id = row['Patient ID'].item()
        pt_num = row['ID (Memory study)'].item()
        date1, did_stim1, date2, did_stim2 = get_pt_info(pt_num)
        print(pt_id, pt_num, date1, date2)

        save_file_for_day(date1, did_stim1, pt_id, pt_num)
        save_file_for_day(date2, did_stim2, pt_id, pt_num)
            