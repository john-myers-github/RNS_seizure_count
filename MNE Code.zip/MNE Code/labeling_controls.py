import math
import glob
import mne
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy
import scipy.stats
from my_ecog_utils import read_with_annotations, get_multitaper_power_bands
from auto_artifact import auto_artifact_from_annot

pt_nums = [fname[-3:] for fname in glob.glob('data/*')]

for pt_num in pt_nums:
    try:
        raw = mne.io.read_raw_fif(f'data/{pt_num}/control_ieeg.fif')
        annot, bads = mne.preprocessing.annotate_flat(raw, bad_percent=90, min_duration=0.02)
        raw.set_annotations(annot)
        raw = auto_artifact_from_annot(raw)
        raw.plot(block=True)
        raw.annotations.save_annotations(f'data/{pt_num}/control_shocks_bad.csv', overwrite=True)
    except:
        continue