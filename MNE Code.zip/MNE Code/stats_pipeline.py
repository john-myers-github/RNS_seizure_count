from itertools import permutations
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy
import scipy.stats
from statsmodels.stats.multitest import fdrcorrection
from typing import Literal

rng = np.random.default_rng()

def fdr_bh(p_vals):
    p = np.asarray(p_vals.values.flatten())
    by_descend = p.argsort()[::-1]
    by_orig = by_descend.argsort()
    steps = float(len(p)) / np.arange(len(p), 0, -1)
    q = np.minimum(1, np.minimum.accumulate(steps * p[by_descend]))
    q[by_orig]
    p_adj = pd.DataFrame(q[by_orig].reshape(p_vals.values.shape), columns=p_vals.columns)
    p_adj['Channel'] = p_vals.index
    return p_adj.set_index('Channel')


def perm_linreg(xs, ys):
    '''Calculates a P-value for the linear regression between xs and ys using
    a permutation test where the xs and ys get paired randomly together and R^2
    values are compared'''
    result_og = scipy.stats.linregress(xs, ys)
    # print(result_og.pvalue)

    if len(ys) < 8:
        y_perms = permutations(ys)
    else:
        y_perms = [rng.permutation(ys) for _ in range(720)]

    rvals = []
    for y_perm in y_perms:
        result = scipy.stats.linregress(xs, y_perm)
        rvals.append(result.rvalue ** 2)
    rvals = pd.Series(rvals)
    return len(rvals[rvals > (result_og.rvalue ** 2)]) / len(rvals)


from IPython.display import display
hip_chans = ['LHip1 - LHip2', 'LHip3 - LHip4', 'RHip1 - RHip2', 'RHip3 - RHip4']
def do_stats(power_and_mem, x, y, xlabel=None, ylabel=None, baselines_only=False,
    mem_null_hyp=0, show_all_p=False, linreg_pval: Literal['t', 'perm', 'kendall']='t', force_avg: Literal['full', 'partial', 'stim', None] =None,
    freqs = ['Delta', 'Theta', 'Alpha', 'Beta', 'Gamma']
    ):
    if xlabel is None:
        xlabel = x
    if ylabel is None:
        ylabel = y

    df = power_and_mem
    if baselines_only:
        df = power_and_mem.drop_duplicates(subset=['ID', 'Trial', 'Channel'])

    # if you're looking at short-term memory, which is measured after each trial,
    # per-stim analyses are invalid. Aggregate df and group by trial to get meaningful results
    x_evald = False
    if force_avg == 'full' or 'Delay_Mem_Stim' in y:
        print('Averaging across stims and trials in the same patient and channel')
        df_averaged = pd.DataFrame()
        if '$FREQ' in x:
            for freq in freqs:
                x_for_freq = x.replace('$FREQ', freq)
                df_averaged[x_for_freq] = df.groupby(['ID', 'Channel']).apply(lambda g: g.eval(x_for_freq)).groupby(['ID', 'Channel']).mean()
        df_mems = df.groupby(['ID', 'Channel']).mean()
        for col in df_mems.columns:
            if col in y:
                df_averaged[col] = df_mems[col]
        df = df_averaged.reset_index()
        # we need to set this true so that we don't evaluate the function of x again later (e.g. log(log(x)))
        x_evald = True
    elif force_avg == 'partial' or 'Memory_Score' in y:
        print('Averaging across stims in the same patient, channel, and trial')
        df_averaged = pd.DataFrame()
        if '$FREQ' in x:
            for freq in freqs:
                x_for_freq = x.replace('$FREQ', freq)
                df_averaged[x_for_freq] = df.groupby(['ID', 'Trial', 'Channel']).apply(lambda g: g.eval(x_for_freq)).groupby(['ID', 'Trial', 'Channel']).mean()
        df_mems = df.groupby(['ID', 'Trial', 'Channel']).mean()
        for col in df_mems.columns:
            if col in y:
                df_averaged[col] = df_mems[col]
        df = df_averaged.reset_index()
        # we need to set this true so that we don't evaluate the function of x again later (e.g. log(log(x)))
        x_evald = True
    elif force_avg == 'stim':
        print('Averaging across trials in the same patient, channel, and stim')
        df_averaged = pd.DataFrame()
        if '$FREQ' in x:
            for freq in freqs:
                x_for_freq = x.replace('$FREQ', freq)
                df_averaged[x_for_freq] = df.groupby(['ID', 'Stim_Num', 'Channel']).apply(lambda g: g.eval(x_for_freq)).groupby(['ID', 'Stim_Num', 'Channel']).mean()
        df_mems = df.groupby(['ID', 'Stim_Num', 'Channel']).mean()
        for col in df_mems.columns:
            if col in y:
                df_averaged[col] = df_mems[col]
        df = df_averaged.reset_index()
        # we need to set this true so that we don't evaluate the function of x again later (e.g. log(log(x)))
        x_evald = True

    num_cols = len(freqs) // 2 + 1
    hist_fig, hist_ax = plt.subplots(2, num_cols)
    hist_fig.set_size_inches(10, 8)

    fig, ax = plt.subplots(2, num_cols)
    fig.set_size_inches(12, 8)
    for i in range(len(freqs)):
        freq = freqs[i]
        xs = df[x.replace('$FREQ', freq)] if x_evald else df.eval(x.replace('$FREQ', freq))
        ys = df.eval(y)
        ax[i//num_cols, i%num_cols].scatter(xs, ys)
        ax[i//num_cols, i%num_cols].set_title(freq)

        hist_ax[i//num_cols, i%num_cols].hist(xs)
        hist_ax[i//num_cols, i%num_cols].set_title(freq)

    hist_ax[1, num_cols-1].hist(ys)
    hist_ax[1, num_cols-1].set_title(ylabel)

    temp_stats = []
    temp_chi = []

    for chan in hip_chans:
        fig, ax = plt.subplots(2, num_cols)
        fig.set_size_inches(12, 10)
        fig.suptitle(chan)
        power_for_chan = df[df['Channel'] == chan]
        for i in range(len(freqs)):
            freq = freqs[i]
            xs = power_for_chan[x.replace('$FREQ', freq)] if x_evald else power_for_chan.eval(x.replace('$FREQ', freq))
            ys = power_for_chan.eval(y)
            ax[i//num_cols, i%num_cols].scatter(xs, ys)
            ax[i//num_cols, i%num_cols].set_title(freq)
            ax[i//num_cols, i%num_cols].set_xlabel(xlabel)
            ax[i//num_cols, i%num_cols].set_ylabel(ylabel)
            result = scipy.stats.linregress(xs, ys)
            line_x = np.array([xs.min(), xs.max()])
            ax[i//num_cols, i%num_cols].plot(line_x, result.slope * line_x + result.intercept, c='orange')
            pval = result.pvalue
            if linreg_pval == 'perm':
                pval = perm_linreg(xs, ys)
            elif linreg_pval == 'kendall':
                pval = scipy.stats.kendalltau(xs, ys).pvalue
            temp_stats.append({
                'Channel': chan,
                'Frequency': freq,
                'r': result.rvalue,
                'P': pval
            })

            # Ran into a problem with chi square because I have very low counts, switching to Fisher's exact
            # reuqires 2-way table, so no change was dropped. idk if that is legal tho
            inc_pow = xs > 0
            dec_pow = xs < 0
            inc_mem = power_for_chan.eval(y) > mem_null_hyp
            # nc_mem = power_for_chan.eval(y) == 0
            dec_mem = power_for_chan.eval(y) < mem_null_hyp
            crosstab = pd.DataFrame([
                [len(power_for_chan[dec_pow & dec_mem]), len(power_for_chan[inc_pow & dec_mem])],
                # [len(power_for_chan[dec_pow & nc_mem]), len(power_for_chan[inc_pow & nc_mem])],
                [len(power_for_chan[dec_pow & inc_mem]), len(power_for_chan[inc_pow & inc_mem])],
            ])
            crosstab.columns = pd.MultiIndex.from_tuples([('Power', 'Decrease'), ('Power', 'Increase')])
            # crosstab.index = pd.MultiIndex.from_tuples([('Memory', 'Decrease'), ('Memory', 'No Change'), ('Memory', 'Increase')])
            crosstab.index = pd.MultiIndex.from_tuples([('Memory', 'Decrease'), ('Memory', 'Increase')])
            chi_sq_p = scipy.stats.fisher_exact(crosstab)[1]
            temp_chi.append({'Channel': chan, 'Frequency': freq, 'P':chi_sq_p})
            if chi_sq_p < 0.50: # TODO reset threshold
                print(f'Fisher Exact P-value = {chi_sq_p} for {freq} band in {chan}')
                display(crosstab)
    stats = pd.DataFrame(temp_stats)
    display(stats)

    p_vals = stats.drop('r', axis=1).set_index(['Channel', 'Frequency']).stack()
    p_vals.index = p_vals.index.droplevel(2)
    p_vals = p_vals.unstack()[freqs]
    p_adj = fdr_bh(p_vals)
    print('Linear regression:')
    display(p_adj if show_all_p else p_adj[p_adj < 0.05])

    chi_stats = pd.DataFrame(temp_chi)
    chi_p = chi_stats.set_index(['Channel', 'Frequency']).stack()
    chi_p.index = chi_p.index.droplevel(2)
    chi_p = chi_p.unstack()[freqs]
    chi_adj = fdr_bh(chi_p)
    print('Fisher Exact:')
    display(chi_adj if show_all_p else chi_adj[chi_adj < 0.05])


# this fxn is still TODO
def mixed_effects_stats(power_and_mem, x, y, xlabel=None, ylabel=None, baselines_only=False,
    mem_null_hyp=0, show_all_p=False, linreg_pval: Literal['t', 'perm', 'kendall']='t',
    force_avg: Literal['full', 'partial', 'stim', None] =None,
    freqs = ['Delta', 'Theta', 'Alpha', 'Beta', 'Gamma']
    ):
    if xlabel is None:
        xlabel = x
    if ylabel is None:
        ylabel = y

    df = power_and_mem
    if baselines_only:
        df = power_and_mem.drop_duplicates(subset=['ID', 'Trial', 'Channel'])

    # if you're looking at short-term memory, which is measured after each trial,
    # per-stim analyses are invalid. Aggregate df and group by trial to get meaningful results
    x_evald = False
    if force_avg == 'full' or 'Delay_Mem_Stim' in y:
        print('Averaging across stims and trials in the same patient and channel')
        df_averaged = pd.DataFrame()
        if '$FREQ' in x:
            for freq in freqs:
                x_for_freq = x.replace('$FREQ', freq)
                df_averaged[x_for_freq] = df.groupby(['ID', 'Channel']).apply(lambda g: g.eval(x_for_freq)).groupby(['ID', 'Channel']).mean()
        df_mems = df.groupby(['ID', 'Channel']).mean()
        for col in df_mems.columns:
            if col in y:
                df_averaged[col] = df_mems[col]
        df = df_averaged.reset_index()
        # we need to set this true so that we don't evaluate the function of x again later (e.g. log(log(x)))
        x_evald = True
    elif force_avg == 'partial' or 'Memory_Score' in y:
        print('Averaging across stims in the same patient, channel, and trial')
        df_averaged = pd.DataFrame()
        if '$FREQ' in x:
            for freq in freqs:
                x_for_freq = x.replace('$FREQ', freq)
                df_averaged[x_for_freq] = df.groupby(['ID', 'Trial', 'Channel']).apply(lambda g: g.eval(x_for_freq)).groupby(['ID', 'Trial', 'Channel']).mean()
        df_mems = df.groupby(['ID', 'Trial', 'Channel']).mean()
        for col in df_mems.columns:
            if col in y:
                df_averaged[col] = df_mems[col]
        df = df_averaged.reset_index()
        # we need to set this true so that we don't evaluate the function of x again later (e.g. log(log(x)))
        x_evald = True
    elif force_avg == 'stim':
        print('Averaging across trials in the same patient, channel, and stim')
        df_averaged = pd.DataFrame()
        if '$FREQ' in x:
            for freq in freqs:
                x_for_freq = x.replace('$FREQ', freq)
                df_averaged[x_for_freq] = df.groupby(['ID', 'Stim_Num', 'Channel']).apply(lambda g: g.eval(x_for_freq)).groupby(['ID', 'Stim_Num', 'Channel']).mean()
        df_mems = df.groupby(['ID', 'Stim_Num', 'Channel']).mean()
        for col in df_mems.columns:
            if col in y:
                df_averaged[col] = df_mems[col]
        df = df_averaged.reset_index()
        # we need to set this true so that we don't evaluate the function of x again later (e.g. log(log(x)))
        x_evald = True

    num_cols = len(freqs) // 2 + 1
    hist_fig, hist_ax = plt.subplots(2, num_cols)
    hist_fig.set_size_inches(10, 8)

    fig, ax = plt.subplots(2, num_cols)
    fig.set_size_inches(12, 8)
    for i in range(len(freqs)):
        freq = freqs[i]
        xs = df[x.replace('$FREQ', freq)] if x_evald else df.eval(x.replace('$FREQ', freq))
        ys = df.eval(y)
        ax[i//num_cols, i%num_cols].scatter(xs, ys)
        ax[i//num_cols, i%num_cols].set_title(freq)

        hist_ax[i//num_cols, i%num_cols].hist(xs)
        hist_ax[i//num_cols, i%num_cols].set_title(freq)

    hist_ax[1, num_cols-1].hist(ys)
    hist_ax[1, num_cols-1].set_title(ylabel)

    temp_stats = []
    temp_chi = []

    for chan in hip_chans:
        fig, ax = plt.subplots(2, num_cols)
        fig.set_size_inches(12, 10)
        fig.suptitle(chan)
        power_for_chan = df[df['Channel'] == chan]
        for i in range(len(freqs)):
            freq = freqs[i]
            xs = power_for_chan[x.replace('$FREQ', freq)] if x_evald else power_for_chan.eval(x.replace('$FREQ', freq))
            ys = power_for_chan.eval(y)
            ax[i//num_cols, i%num_cols].scatter(xs, ys)
            ax[i//num_cols, i%num_cols].set_title(freq)
            ax[i//num_cols, i%num_cols].set_xlabel(xlabel)
            ax[i//num_cols, i%num_cols].set_ylabel(ylabel)
            result = scipy.stats.linregress(xs, ys)
            line_x = np.array([xs.min(), xs.max()])
            ax[i//num_cols, i%num_cols].plot(line_x, result.slope * line_x + result.intercept, c='orange')
            pval = result.pvalue
            if linreg_pval == 'perm':
                pval = perm_linreg(xs, ys)
            elif linreg_pval == 'kendall':
                pval = scipy.stats.kendalltau(xs, ys).pvalue
            temp_stats.append({
                'Channel': chan,
                'Frequency': freq,
                'r': result.rvalue,
                'P': pval
            })

            # Ran into a problem with chi square because I have very low counts, switching to Fisher's exact
            # reuqires 2-way table, so no change was dropped. idk if that is legal tho
            inc_pow = xs > 0
            dec_pow = xs < 0
            inc_mem = power_for_chan.eval(y) > mem_null_hyp
            # nc_mem = power_for_chan.eval(y) == 0
            dec_mem = power_for_chan.eval(y) < mem_null_hyp
            crosstab = pd.DataFrame([
                [len(power_for_chan[dec_pow & dec_mem]), len(power_for_chan[inc_pow & dec_mem])],
                # [len(power_for_chan[dec_pow & nc_mem]), len(power_for_chan[inc_pow & nc_mem])],
                [len(power_for_chan[dec_pow & inc_mem]), len(power_for_chan[inc_pow & inc_mem])],
            ])
            crosstab.columns = pd.MultiIndex.from_tuples([('Power', 'Decrease'), ('Power', 'Increase')])
            # crosstab.index = pd.MultiIndex.from_tuples([('Memory', 'Decrease'), ('Memory', 'No Change'), ('Memory', 'Increase')])
            crosstab.index = pd.MultiIndex.from_tuples([('Memory', 'Decrease'), ('Memory', 'Increase')])
            chi_sq_p = scipy.stats.fisher_exact(crosstab)[1]
            temp_chi.append({'Channel': chan, 'Frequency': freq, 'P':chi_sq_p})
            if chi_sq_p < 0.50: # TODO reset threshold
                print(f'Fisher Exact P-value = {chi_sq_p} for {freq} band in {chan}')
                display(crosstab)
    stats = pd.DataFrame(temp_stats)
    display(stats)

    p_vals = stats.drop('r', axis=1).set_index(['Channel', 'Frequency']).stack()
    p_vals.index = p_vals.index.droplevel(2)
    p_vals = p_vals.unstack()[freqs]
    p_adj = fdr_bh(p_vals)
    print('Linear regression:')
    display(p_adj if show_all_p else p_adj[p_adj < 0.05])

    chi_stats = pd.DataFrame(temp_chi)
    chi_p = chi_stats.set_index(['Channel', 'Frequency']).stack()
    chi_p.index = chi_p.index.droplevel(2)
    chi_p = chi_p.unstack()[freqs]
    chi_adj = fdr_bh(chi_p)
    print('Fisher Exact:')
    display(chi_adj if show_all_p else chi_adj[chi_adj < 0.05])


from scipy.stats import linregress
from seaborn import heatmap

def make_heatmap_linreg(df, x, y, freqs, xlabel=None, ylabel=None, ax=None):
    if xlabel is None:
        xlabel = x
    if ylabel is None:
        ylabel = y
    t_arr = np.ndarray(shape=(len(hip_chans), len(freqs)))
    pvals = pd.DataFrame()
    for i, chan in enumerate(hip_chans):
        power_for_chan = df[df['Channel'] == chan]
        for j, freq in enumerate(freqs):
            if '_log_' in x:
                results = linregress(power_for_chan[x.replace('$FREQ', freq)], power_for_chan[y])
            else:
                results = linregress(np.log10(power_for_chan[x.replace('$FREQ', freq)]), power_for_chan[y])
            t_arr[i][j] = results.slope / results.stderr
            pvals.loc[freq, chan] = results.pvalue
            if results.pvalue < 0.05:
                print(f"{chan} {freq}: r = {results.rvalue}, p = {results.pvalue}")

    formal_freqs = freqs.copy()
    # formal_freqs[0]  = '0.1-3.0 Hz'
    # formal_freqs[1]  = '4-7 Hz'
    # formal_freqs[2]  = '8-12 Hz'
    # formal_freqs[3]  = '13-30 Hz'
    # formal_freqs[4] = '40-57 Hz'
    # formal_freqs[5] = '67-100 Hz'

    # p_within_ea_col = pvals.apply(lambda x: fdrcorrection(x)[1], axis=0)
    # p_within_ea_row = pvals.T.apply(lambda x: fdrcorrection(x)[1], axis=0).T
    # p_stars = np.where(p_within_ea_col < 0.05, '*', '')
    # p_stars = np.where(p_within_ea_row < 0.05, '†', p_stars)
    # p_stars = np.where((p_within_ea_col < 0.05) & (p_within_ea_row < 0.05), '*†', p_stars)

    p_stars = np.where(fdr_bh(pvals) < 0.05, '*', '')

    heatmap(t_arr.T, xticklabels=['Left\nAnterior', 'Left\nPosterior', 'Right\nAnterior', 'Right\nPosterior'], yticklabels=formal_freqs, \
        center=0, vmin=-5, vmax=5, annot=p_stars, fmt='', ax=ax) \
        .set(title=f"{xlabel} vs {ylabel}")


import statsmodels.formula.api as smf

def make_heatmap_mixed(df, x, y, freqs, xlabel=None, ylabel=None, ax=None):
    if xlabel is None:
        xlabel = x
    if ylabel is None:
        ylabel = y

    t_arr = np.ndarray(shape=(len(hip_chans), len(freqs)))
    pvals = pd.DataFrame()
    for i, chan in enumerate(hip_chans):
        power_for_chan = df[df['Channel'] == chan]

        formula = y + " ~ "
        for j, freq in enumerate(freqs):
            var = x.replace('$FREQ', freq) if '_log_' in x else "np.log10("+x.replace('$FREQ', freq)+")"
            # var = x.replace('$FREQ', freq)
            formula = y + " ~ " + var
            model = smf.mixedlm(formula, power_for_chan, groups=power_for_chan['ID'])
            result = model.fit()
            t_arr[i][j] = result.tvalues[1]
            pvals.loc[freq, chan] = result.pvalues[1]
            if result.pvalues[1] < 0.05:
                print(f"{chan} {freq}: {result.pvalues[1]}")

    # p_within_ea_col = pvals.apply(lambda x: fdrcorrection(x)[1], axis=0)
    # p_within_ea_row = pvals.T.apply(lambda x: fdrcorrection(x)[1], axis=0).T
    # p_stars = np.where(p_within_ea_col < 0.05, '*', '')
    # p_stars = np.where(p_within_ea_row < 0.05, '†', p_stars)
    # p_stars = np.where((p_within_ea_col < 0.05) & (p_within_ea_row < 0.05), '*†', p_stars)

    p_stars = np.where(pvals < 0.05, '*', '')

    heatmap(t_arr.T, xticklabels=['LAH', 'LPH', 'RAH', 'RPH'], yticklabels=freqs, center=0, \
            annot=p_stars, fmt='', vmin=-5, vmax=5, ax=ax) \
            .set(title=f"{xlabel} vs {ylabel}")


from scipy.stats import kendalltau

def make_heatmap_kendalltau(df, x, y, freqs, xlabel=None, ylabel=None, ax=None):
    if xlabel is None:
        xlabel = x
    if ylabel is None:
        ylabel = y
    t_arr = np.ndarray(shape=(len(hip_chans), len(freqs)))
    pvals = pd.DataFrame()
    for i, chan in enumerate(hip_chans):
        power_for_chan = df[df['Channel'] == chan]
        for j, freq in enumerate(freqs):
            if '_log_' in x:
                results = kendalltau(power_for_chan[x.replace('$FREQ', freq)], power_for_chan[y])
            else:
                results = kendalltau(np.log10(power_for_chan[x.replace('$FREQ', freq)]), power_for_chan[y])
            t_arr[i][j] = results[0]
            pvals.loc[freq, chan] = results[1]
            if results.pvalue < 0.05:
                print(f"{chan} {freq}: T = {results[0]}, p = {results[1]}")

    formal_freqs = freqs.copy()
    formal_freqs[0]  = '0.1-3.0 Hz'
    formal_freqs[1]  = '4-7 Hz'
    formal_freqs[2]  = '8-12 Hz'
    formal_freqs[3]  = '13-30 Hz'
    formal_freqs[4] = '40-57 Hz'
    formal_freqs[5] = '67-1000 Hz'

    p_within_ea_col = pvals.apply(lambda x: fdrcorrection(x)[1], axis=0)
    p_within_ea_row = pvals.T.apply(lambda x: fdrcorrection(x)[1], axis=0).T
    p_stars = np.where(p_within_ea_col < 0.05, '*', '')
    p_stars = np.where(p_within_ea_row < 0.05, '†', p_stars)
    p_stars = np.where((p_within_ea_col < 0.05) & (p_within_ea_row < 0.05), '*†', p_stars)

    heatmap(t_arr.T, xticklabels=['LAH', 'LPH', 'RAH', 'RPH'], \
        yticklabels=formal_freqs, center=0, vmin=-0.5, vmax=0.5, annot=p_stars, fmt='', ax=ax) \
        .set(title=f"{xlabel} vs {ylabel}")

