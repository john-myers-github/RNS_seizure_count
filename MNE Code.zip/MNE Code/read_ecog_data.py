import sys
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import mne

GAIN = 0.80e-6 # 80 uV
# Look at DAT File interpretation to see what the gain settings are
# TODO check which system we are using

def read_header(catalog: str, datfile: str):
    '''
    Reads the ***ECoG_Catalog.csv file and returns metadata about the recordings
    
    datfile is the relative path to the datfile that we are currently trying to
    read.
    '''
    if not catalog.endswith('.csv'):
        print(catalog)
        raise ValueError('catalog must be a CSV file')
    
    df = pd.read_csv(catalog)
    return df[df['Filename'] == os.path.split(datfile)[1]]


def read_dat_file(datfile: str, catalog: str):
    '''
    Reads a DAT file from NeuroPort and converts it into MNE Raw ECoG data
    '''
    metadata = read_header(catalog, datfile)

    bin_data = np.fromfile(datfile, 'int16')
    bin_data -= 512
    bin_data = bin_data.astype('float')
    bin_data *= GAIN
    waveforms = int(metadata.loc[:,'Waveform count'])
    print(waveforms)
    if waveforms != 4:
        print('TODO: Account for situations where one of the electrodes is disabled')
        sys.exit(1)
    ch_1 = bin_data[0::waveforms]
    ch_2 = bin_data[1::waveforms]
    ch_3 = bin_data[2::waveforms]
    ch_4 = bin_data[3::waveforms]
    raw_data = np.array([ch_1, ch_2, ch_3, ch_4])

    ch_1_name = metadata.loc[:, 'Ch 1 name'].item()
    ch_2_name = metadata.loc[:, 'Ch 2 name'].item()
    ch_3_name = metadata.loc[:, 'Ch 3 name'].item()
    ch_4_name = metadata.loc[:, 'Ch 4 name'].item()
    ch_names = [ch_1_name, ch_2_name, ch_3_name, ch_4_name]
    ch_types = ['ecog' for i in range(4)]
    sfreq = metadata.loc[:, 'Sampling rate']
    info = mne.create_info(ch_names, sfreq, ch_types=ch_types)
    return mne.io.RawArray(raw_data, info)


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print('Usage: python read_ecog_data.py My_ECoG_Catalog.csv 1234567000.dat')
        sys.exit(1)
    
    datfile = sys.argv[2]
    raw = read_dat_file(datfile, sys.argv[1])
    raw.plot(block=True)

    

    

