import mne

def read_with_annotations(pt_num, stim='stimulated', annotations='auto'):
    raw = mne.io.read_raw_fif(f"data/{pt_num}/{stim}_ieeg.fif")
    try:
        if annotations == 'auto':
            saved_ann = mne.read_annotations(f"data/{pt_num}/auto_annotated.csv")
            if stim != 'stimulated':
                raise ValueError("No auto annotations available for control recordings")
        elif annotations== 'manual':
            saved_ann = mne.read_annotations(f"data/{pt_num}/{stim}_shocks_bad.csv")
        else:
            saved_ann = mne.read_annotations(f"data/{pt_num}/{annotations}.csv")
        raw.set_meas_date(0)
        raw.set_annotations(saved_ann)
    except (IndexError, FileNotFoundError):
        # gets thrown if the annotations CSV is empty, which is true for many of the control recordings
        print(f'No annotations found for pt {pt_num}')
        pass
    return raw


def get_multitaper_power_bands(raw, picks=None, split_gamma=False):
    '''gets power bands given a mne.Raw or mne.Epochs object using the Multitaper method
    to estimate spectral power. I recommend using this method for Epochs objects but applying
    multitaper to Raw, since that's what MNE's graphing does. I think this is because multitaper
    is more accurate, but more computationally expensive, so it makes more sense for shorter data'''
    delta = mne.time_frequency.psd_multitaper(raw, picks=picks, verbose='WARNING', fmin=1, fmax=3)[0].mean()
    theta = mne.time_frequency.psd_multitaper(raw, picks=picks, verbose='WARNING', fmin=4, fmax=7)[0].mean()
    alpha = mne.time_frequency.psd_multitaper(raw, picks=picks, verbose='WARNING', fmin=8, fmax=12)[0].mean()
    beta =  mne.time_frequency.psd_multitaper(raw, picks=picks, verbose='WARNING', fmin=13, fmax=30)[0].mean()
    gamma_full = mne.time_frequency.psd_multitaper(raw, picks=picks, verbose='WARNING', fmin=31, fmax=100)[0].mean()
    if split_gamma:
        gamma_low = mne.time_frequency.psd_multitaper(raw, picks=picks, verbose='WARNING', fmin=40, fmax=57)[0].mean()
        # skipping the artifact that pt 112 and 115 have from 57-67 Hz
        gamma_high = mne.time_frequency.psd_multitaper(raw, picks=picks, verbose='WARNING', fmin=67, fmax=100)[0].mean()
    return {
        'Delta': delta,
        'Theta': theta,
        'Alpha': alpha,
        'Beta': beta,
        'GammaLow': gamma_low,
        'GammaHigh': gamma_high
    } if split_gamma else {
        'Delta': delta,
        'Theta': theta,
        'Alpha': alpha,
        'Beta': beta,
        'Gamma': gamma_full,
    }


def get_multitaper_power_bands_narrow(raw, picks=None):
    '''gets power bands given a mne.Raw or mne.Epochs object using the Multitaper method
    to estimate spectral power. I recommend using this method for Epochs objects but applying
    multitaper to Raw, since that's what MNE's graphing does. I think this is because multitaper
    is more accurate, but more computationally expensive, so it makes more sense for shorter data'''
    delta = mne.time_frequency.psd_multitaper(raw, picks=picks, verbose='WARNING', fmin=0.1, fmax=3)[0].mean()
    theta = mne.time_frequency.psd_multitaper(raw, picks=picks, verbose='WARNING', fmin=4, fmax=7)[0].mean()
    # alpha = mne.time_frequency.psd_multitaper(raw, picks=picks, verbose='WARNING', fmin=8, fmax=12)[0].mean()
    # beta =  mne.time_frequency.psd_multitaper(raw, picks=picks, verbose='WARNING', fmin=14.5, fmax=19.5)[0].mean()
    gamma_low = mne.time_frequency.psd_multitaper(raw, picks=picks, verbose='WARNING', fmin=41.5, fmax=46.5)[0].mean()
    gamma_med = mne.time_frequency.psd_multitaper(raw, picks=picks, verbose='WARNING', fmin=82.5, fmax=87.5)[0].mean()
    gamma_high = mne.time_frequency.psd_multitaper(raw, picks=picks, verbose='WARNING', fmin=101.5, fmax=106.5)[0].mean()
    gamma_extra_high = mne.time_frequency.psd_multitaper(raw, picks=picks, verbose='WARNING', fmin=116.5, fmax=121.5)[0].mean()
    return {
        'Delta': delta,
        'Theta': theta,
        'GammaLow': gamma_low,
        'GammaMed': gamma_med,
        'GammaHigh': gamma_high,
        'GammaXHigh': gamma_extra_high,
    }


def get_raw_power_bands(raw, picks=None):
    '''gets power bands given a mne.Raw or mne.Epochs object using the Welch method
    to estimate spectral power. I recommend using this method for Raw objects but applying
    multitaper to Epochs, since that's what MNE's graphing does'''
    delta = mne.time_frequency.psd_welch(raw, picks=picks, fmin=0.1, fmax=3)[0].mean()
    theta = mne.time_frequency.psd_welch(raw, picks=picks, fmin=4, fmax=7)[0].mean()
    alpha = mne.time_frequency.psd_welch(raw, picks=picks, fmin=8, fmax=12)[0].mean()
    beta =  mne.time_frequency.psd_welch(raw, picks=picks, fmin=13, fmax=30)[0].mean()
    gamma = mne.time_frequency.psd_welch(raw, picks=picks, fmin=31, fmax=100)[0].mean()
    return {
        'Delta': delta,
        'Theta': theta,
        'Alpha': alpha,
        'Beta': beta,
        'Gamma': gamma
    }


def get_raw_power_bands_narrow(raw, picks=None):
    '''gets power bands given a mne.Raw or mne.Epochs object using the Welch method
    to estimate spectral power. I recommend using this method for Raw objects but applying
    multitaper to Epochs, since that's what MNE's graphing does'''
    # delta = mne.time_frequency.psd_welch(raw, picks=picks, fmin=0.1, fmax=3)[0].mean()
    # alpha = mne.time_frequency.psd_welch(raw, picks=picks, fmin=7.5, fmax=12.5)[0].mean()
    # beta =  mne.time_frequency.psd_welch(raw, picks=picks, fmin=19.5, fmax=24.5)[0].mean()
    # gamma_low = mne.time_frequency.psd_welch(raw, picks=picks, fmin=33, fmax=38)[0].mean()
    # gamma_med = mne.time_frequency.psd_welch(raw, picks=picks, fmin=45.5, fmax=49.5)[0].mean()
    # return {
    #     'Delta': delta,
    #     'Alpha': alpha,
    #     'Beta': beta,
    #     'GammaLow': gamma_low,
    #     'GammaMed': gamma_med,
    # }

    delta = mne.time_frequency.psd_welch(raw, picks=picks, verbose='WARNING', fmin=0.1, fmax=3)[0].mean()
    theta = mne.time_frequency.psd_welch(raw, picks=picks, verbose='WARNING', fmin=4, fmax=7)[0].mean()
    alpha = mne.time_frequency.psd_welch(raw, picks=picks, verbose='WARNING', fmin=8, fmax=12)[0].mean()
    beta =  mne.time_frequency.psd_welch(raw, picks=picks, verbose='WARNING', fmin=13, fmax=30)[0].mean() 
    gamma_low = mne.time_frequency.psd_welch(raw, picks=picks, verbose='WARNING', fmin=40, fmax=57)[0].mean()
    # skipping the artifact that pt 112 and 115 have from 57-67 Hz
    gamma_med = mne.time_frequency.psd_welch(raw, picks=picks, verbose='WARNING', fmin=67, fmax=80)[0].mean()
    gamma_high = mne.time_frequency.psd_welch(raw, picks=picks, verbose='WARNING', fmin=80, fmax=100)[0].mean()
    gamma_xhigh = mne.time_frequency.psd_welch(raw, picks=picks, verbose='WARNING', fmin=100, fmax=120)[0].mean()
    return {
        'Delta': delta,
        'Theta': theta,
        'Beta': beta,
        'Alpha': alpha,
        'GammaLow': gamma_low,
        'GammaMed': gamma_med,
        'GammaHigh': gamma_high,
        'GammaXHigh': gamma_xhigh,
    }