import sys
from find_rns_patients import get_pt_info, find_files_for_day, pt_id_map, ONE_DRIVE

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print(f'Usage: python {sys.argv[0]} <pt_num> <stim>, where <stim> = 1 or 0')
        sys.exit(1)
    
    pt_num = int(sys.argv[1])
    did_stim = sys.argv[2] == '1'
    pt_id = pt_id_map[pt_id_map['ID (Memory study)'] == pt_num]['Patient ID'].item()
    date1, did_stim1, date2, did_stim2 = get_pt_info(pt_num)
    date = date1 if did_stim1 == did_stim else date2

    catalog_path = f"{ONE_DRIVE}/ECoG Data/{pt_id}/{pt_id}_ECoG_Catalog.csv"
    fnames = find_files_for_day(catalog_path, date)
    print(f'Found {len(fnames)} files for pt {pt_num}\'s {"stimulated" if did_stim else "control"} day')
