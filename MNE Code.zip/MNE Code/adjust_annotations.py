import sys
import mne
import numpy as np
from my_ecog_utils import read_with_annotations

def relabel_pre_shock_raw(raw, duration):
    # find the first shock (BAD_ annotation) after each pre_shock
    # and then record the start times
    trial_start_times = np.empty(0)
    # DEBUG
    # print(trial_start_times)
    for idx, desc in enumerate(raw.annotations.description):
        if desc == 'pre_shock':
            # DEBUG
            # print(f'shock at {raw.annotations.onset[idx]}')
            for i in range(idx, len(raw.annotations.description)):
                if raw.annotations.description[i] == 'BAD_':
                    trial_start_times = np.append(trial_start_times, raw.annotations.onset[i])
                    break

    print(trial_start_times)

    # remove the old pre_shock labels
    old_pre_shocks_present = True
    while old_pre_shocks_present:
        idx_to_remove = -1
        for idx, desc in enumerate(raw.annotations.description):
            if desc == 'pre_shock':
                idx_to_remove = idx
                break
        raw.annotations.delete(idx_to_remove)
        if 'pre_shock' not in raw.annotations.description:
            old_pre_shocks_present = False

    # add new pre_shock labels
    for trial_start_time in trial_start_times:
        raw.annotations.append(trial_start_time - duration - 2 / raw.info['sfreq'], duration, 'pre_shock')

    evts, event_id = mne.events_from_annotations(raw, {'BAD_': 0, 'post_shock': 2, 'pre_shock': 1})
    epochs = mne.Epochs(raw, evts, event_id=event_id, tmin=0, tmax=1, baseline=(0.5,1.0))
    epochs.drop_bad()
    for drop_status in epochs.drop_log:
        if drop_status != ():
            print(f'WARNING: dropped epoch for pt {pt_num} using pre_shock duration {duration}')

    return raw

def relabel_pre_shock(pt_num, duration):
    raw = read_with_annotations(pt_num)
    return relabel_pre_shock_raw(raw, duration)


def relabel_every_pre(pt_num, duration):
    raw = read_with_annotations(pt_num)
    ann = raw.annotations
    anns_to_add = []
    for idx, annot in enumerate(ann):
        if annot['description'] == 'post_shock':
            # count backwards until we find the shock that immediately precedes this post-shock epoch
            onset = 0
            for j in range(idx, -1, -1):
                if ann[j]['description'] == 'BAD_':
                    # create a new pre-stim epoch that starts right before the shock
                    anns_to_add.append(ann[j]['onset'] - (duration + 0.006))
                    break

    # remove all of the existing pre-shock epochs
    idx = 0
    while idx < len(ann):
        if ann[idx]['description'] == 'pre_shock':
            ann.delete(idx)
            idx = 0
        else:
            idx += 1

    # add new pre-shock epochs
    for onset in anns_to_add:
        ann.append(onset, duration, 'pre_shock')
    raw.set_annotations(ann)
    return raw


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print('Usage:')
        print(f'python {sys.argv[0]} 1.0 all')
        print(f'python {sys.argv[0]} 1.0 110')
        sys.exit(0)
    if sys.argv[2] == 'all':
        duration = float(sys.argv[1])
        pts_w_any_stim = [100, 103, 105, 110, 111, 112, 113, 115, 202]
        print(f'Relabeling {pts_w_any_stim}')
        for pt_num in pts_w_any_stim:
            raw = relabel_pre_shock(pt_num, duration)
            raw.annotations.save(f'data/{pt_num}/auto_annotated.csv', overwrite=True)
    elif sys.argv[2] == 'every_pre':
        duration = float(sys.argv[1])
        pts_w_any_stim = [100, 103, 105, 106, 109, 110, 111, 112, 113, 115, 202]
        # 103 might need a little correction because there appears to be a duplicate pre_shock
        print(f'Relabeling {pts_w_any_stim}')
        for pt_num in pts_w_any_stim:
            raw = relabel_every_pre(pt_num, duration)
            raw.annotations.save(f'data/{pt_num}/every_pre.csv', overwrite=True)
    else:
        duration = float(sys.argv[1])
        pt_num = sys.argv[2]
        raw = relabel_pre_shock(pt_num, duration)
        raw.annotations.save(f'data/{pt_num}/auto_annotated.csv', overwrite=True)
        
